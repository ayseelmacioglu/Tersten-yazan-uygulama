﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SayiTahminOyunu
{ 



public  partial class Form1 : Form
{
    private int sayi1;
    private int sayac = 0;
    Random rnd = new Random();

    public Form1()
    {
        InitializeComponent();
        sayi1 = rnd.Next(1, 100); // 1 ile 100 arasında bir sayı üretir
    }

    private void btnTahmin_Click(object sender, EventArgs e)
    {
        int gelensayi;
        if (!int.TryParse(txtTahmin.Text, out gelensayi))
        {
            MessageBox.Show("Lütfen geçerli bir sayı girin.");
            return;
        }

        sayac++;

        if (sayi1 > gelensayi)
        {
            lblTahmin.Text = sayac + ". Denemeniz: Daha büyük bir değer giriniz";
        }
        else if (sayi1 < gelensayi)
        {
            lblTahmin.Text = sayac + ". Denemeniz: Daha küçük bir değer giriniz";
        }
        else
        {
            DialogResult res = MessageBox.Show(sayac + ". denemede buldunuz TEBRİKLER! Tekrar oynamak ister misiniz?",
                                                "Bilgilendirme", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (res == DialogResult.Yes)
            {
                Application.Restart(); // Uygulamayı yeniden başlat
            }
            else
            {
                // Hiçbir şey yapılmaz
            }
        }
    }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
