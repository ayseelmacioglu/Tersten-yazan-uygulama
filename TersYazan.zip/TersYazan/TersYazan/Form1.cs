﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TersYazan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 0)
            {
                char[] harfler = textBox1.Text.ToCharArray();

                Array.Reverse(harfler);

                textBox2.Text = new string(harfler);

            }
            else {
                MessageBox.Show("Lütfen Önce Metni Giriniz..","Bilgi");
            
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(textBox2.Text);
            MessageBox.Show("Metin Kopyalandı!","Bilgi");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            Clipboard.SetText("-");
        }
    }
}
