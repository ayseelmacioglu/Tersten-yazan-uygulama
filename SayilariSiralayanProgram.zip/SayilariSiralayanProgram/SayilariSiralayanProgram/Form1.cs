﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SayilariSiralayanProgram
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            SortNumbers();
        }

        private void rbAscend_CheckedChanged(object sender, EventArgs e)
        {
            if (rbAscend.Checked || rbDescend.Checked)
            {
                SortNumbers();
            }
        }

        private void rbDescend_CheckedChanged(object sender, EventArgs e)
        {
            if (rbAscend.Checked || rbDescend.Checked)
            {
                SortNumbers();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNumbers.Clear(); 
            lstResults.Items.Clear(); 
            rbAscend.Checked = false;
            rbDescend.Checked = false; 
        }

        private void SortNumbers()
        {
            string input = txtNumbers.Text;
            string[] stringNumbers = input.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);

            int[] numbers;
            try
            {
                numbers = stringNumbers.Select(s => int.Parse(s)).ToArray();
            }
            catch (FormatException)
            {
                MessageBox.Show("Lütfen geçerli sayılar giriniz.");
                return;
            }

            if (rbAscend.Checked)
            {
                BubbleSort(numbers, ascending: true);
            }
            else if (rbDescend.Checked)
            {
                BubbleSort(numbers, ascending: false);
            }
            else
            {
                MessageBox.Show("Sıralama yönü seçilmedi.");
                return;
            }

            lstResults.Items.Clear();
            foreach (int number in numbers)
            {
                lstResults.Items.Add(number);
            }
        }

        private void BubbleSort(int[] array, bool ascending)
        {
            int n = array.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if ((ascending && array[j] > array[j + 1]) || (!ascending && array[j] < array[j + 1]))
                    {
                        // Swap
                        int temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            txtNumbers.Clear(); // TextBox içeriğini temizle
            lstResults.Items.Clear(); // ListBox içeriğini temizle
            rbAscend.Checked = false; // RadioButton seçimini kaldır
            rbDescend.Checked = false; // RadioButton seçimini kaldır
        }
    }
}
        
    

