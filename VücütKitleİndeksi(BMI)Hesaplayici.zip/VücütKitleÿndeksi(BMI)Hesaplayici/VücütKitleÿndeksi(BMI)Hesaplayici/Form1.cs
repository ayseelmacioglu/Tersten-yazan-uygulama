﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VücütKitleİndeksi_BMI_Hesaplayici
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double boy, kilo, index;
        string skilo, ideal;

        private void BMIHesapla()
        {
            boy = Convert.ToDouble(textBox1.Text);
            kilo = Convert.ToDouble(textBox2.Text);
            boy = boy / 100;
            index = kilo / (boy * boy);
        }

        private void kontrol1()
        {
            if (index >= 0 && index <= 18.4)
            {
                skilo = "Zayıf, Kilo Almalısınız.";

            }
            else if (index >= 18.5 && index <= 24.9)
            {
                skilo = "Normal ve İdeal Kilodasınız.";
            }
            else if (index >= 25 && index <= 29.9)
            {
                skilo = "Fazla Kilolu, Kilo Vermelisiniz.";
            }

        }

        private void listeyeEkle()
        {
            listBox1.Items.Add("BMI :" + Math.Round(index, 4));
            listBox1.Items.Add("Kilo Durumu:" + skilo);
            listBox1.Items.Add("İdeal Kilo :" + ideal);
            listBox1.Items.Add("---");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Temizle();
        }

        private void Temizle()
        {
            textBox1.Clear();
            textBox2.Clear();
            listBox1.Items.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            BMIHesapla();
            
            kontrol1();
           
            listeyeEkle();


        }
        private void button2_Click(object sender, EventArgs e)
        {
            Temizle();
        }

    }
}
