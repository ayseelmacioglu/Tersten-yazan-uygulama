﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Basit_ATM_Uygulamasi
{
    public partial class Form1 : Form
    {
        double bakiye = 1000; // Bu satır değişken tanımlamasını yapar.

        public Form1()
        {
            InitializeComponent();
        }

        private void btnBakiyeSorgula_Click(object sender, EventArgs e)
        {
            lblBakiye.Text = "Mevcut bakiyeniz: " + bakiye.ToString() + " TL";
        }

        private void btnParaCek_Click(object sender, EventArgs e)
        {
            double miktar = double.Parse(txtMiktar.Text);
            if (miktar <= bakiye)
            {
                bakiye -= miktar;
                lblBakiye.Text = "Mevcut bakiyeniz: " + bakiye.ToString() + " TL";
                MessageBox.Show(miktar.ToString() + " TL çekildi.");
            }
            else
            {
                MessageBox.Show("Yetersiz bakiye!");
            }
        }

        private void btnParaYatir_Click(object sender, EventArgs e)
        {
            double miktar = double.Parse(txtMiktar.Text);
            bakiye += miktar;
            lblBakiye.Text = "Mevcut bakiyeniz: " + bakiye.ToString() + " TL";
            MessageBox.Show(miktar.ToString() + " TL yatırıldı.");
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
