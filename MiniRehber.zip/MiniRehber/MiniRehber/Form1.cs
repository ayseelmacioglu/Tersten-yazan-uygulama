﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MiniRehber
{
    public partial class Form1 : Form
    {
        // Telefon rehberindeki kişileri tutan liste
        private List<Contact> contacts = new List<Contact>();

        public Form1()
        {
            InitializeComponent();

            // Butonların Click olaylarına metotları bağla
            btnAdd.Click += BtnAdd_Click;
            btnDelete.Click += BtnDelete_Click;
            btnList.Click += BtnList_Click;
        }

        // 'Ekle' butonuna tıklanınca çalışacak işlem
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim(); // İsim metin kutusundan alınır ve boşluklar temizlenir
            string phoneNumber = txtPhoneNumber.Text.Trim(); // Telefon numarası metin kutusundan alınır ve boşluklar temizlenir

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(phoneNumber))
            {
                MessageBox.Show("Lütfen hem isim hem de telefon numarası girin.");
                return;
            }

            // Yeni kişiyi listeye ekle
            contacts.Add(new Contact { Name = name, PhoneNumber = phoneNumber });

            // TextBox'ları temizle
            txtName.Text = "";
            txtPhoneNumber.Text = "";

            MessageBox.Show("Kişi başarıyla eklendi.");

            // Eklendikten sonra listeyi güncelle
            ListContacts();
        }

        // 'Sil' butonuna tıklanınca çalışacak işlem
        private void BtnDelete_Click(object sender, EventArgs e)
        {
            // ListBox'tan seçili olan kişiyi sil
            if (lstPhoneBook.SelectedIndex != -1)
            {
                contacts.RemoveAt(lstPhoneBook.SelectedIndex); // Seçili olan kişiyi listeden çıkar
                MessageBox.Show("Kişi başarıyla silindi.");

                // Silindikten sonra listeyi güncelle
                ListContacts();
            }
            else
            {
                MessageBox.Show("Lütfen silmek için listeden bir kişi seçin.");
            }
        }

        // 'Listele' butonuna tıklanınca çalışacak işlem
        private void BtnList_Click(object sender, EventArgs e)
        {
            ListContacts(); // Rehberi listele
        }

        // Rehberdeki kişileri ListBox'a ekle
        private void ListContacts()
        {
            lstPhoneBook.Items.Clear(); // ListBox'ı temizle
            foreach (var contact in contacts)
            {
                lstPhoneBook.Items.Add($"{contact.Name} - {contact.PhoneNumber}"); // Her kişiyi ListBox'a ekle
            }
        }
    }

    // Kişi sınıfı
    public class Contact
    {
        public string Name { get; set; } // İsim özelliği
        public string PhoneNumber { get; set; } // Telefon numarası özelliği
    }
}