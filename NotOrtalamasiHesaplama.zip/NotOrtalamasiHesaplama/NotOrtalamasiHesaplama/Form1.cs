﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NotOrtalamasiHesaplama
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            double s1, s2, s3, ort;
            s1 = Convert.ToDouble(textBox1.Text);
            s2 = Convert.ToDouble(textBox2.Text);
            s3 = Convert.ToDouble(textBox3.Text);
            ort = (s1 + s2 + s3) / 3;
            if (ort>=50 && ort<=100)
            {
                label6.Text = ort.ToString("0.0");
                label5.Text = " geçti";
            }
            else
            {
                label6.Text = ort.ToString("0.0");
                label5.Text = "kaldı";







            }
        }
    }
}
