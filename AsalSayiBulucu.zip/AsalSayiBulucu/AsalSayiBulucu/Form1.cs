﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsalSayiBulucu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheckPrime_Click(object sender, EventArgs e)
        {
            int number;
            bool isPrime = true;

            // Kullanıcıdan girilen sayıyı kontrol et ve integer'a dönüştür
            if (int.TryParse(txtNumber.Text, out number))
            {
                if (number <= 1)
                {
                    isPrime = false; // 1 ve daha küçük sayılar asal değildir
                }
                else
                {
                    // Sayının asal olup olmadığını kontrol et
                    for (int i = 2; i <= Math.Sqrt(number); i++)
                    {
                        if (number % i == 0)
                        {
                            isPrime = false;
                            break;
                        }
                    }
                }

                // Sonucu ekrana yazdır
                if (isPrime)
                {
                    lblResult.Text = $"{number} bir asal sayıdır.";
                }
                else
                {
                    lblResult.Text = $"{number} bir asal sayı değildir.";
                }
            }
            else
            {
                lblResult.Text = "Lütfen geçerli bir sayı girin.";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}





